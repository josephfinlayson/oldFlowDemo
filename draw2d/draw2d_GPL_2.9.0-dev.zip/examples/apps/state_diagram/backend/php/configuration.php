<?php

$PHPBLOCKS_CONFDIR   = dirname(__FILE__);
$PHPBLOCKS_DATADIR   = $PHPBLOCKS_CONFDIR . "/data/";

//$PHPBLOCKS_DATADIR   = "/Users/andherz/Documents/workspace/draw2d_touch/examples/apps/state_diagram/backend/php/data/";
$PHPBLOCKS_DATADIR   = "/Users/d023280/Documents/workspace/draw2d_touch/examples/apps/state_diagram/backend/php/data/";

date_default_timezone_set("Europe/Dublin");
?>
